
#include <stddef.h>
void *ft_memset(void *s, int c, size_t n)
{
    char  *str;
    
    str = ' ' ;
    *str = (char *)s;
    while (*str < n)
    {
        *str = c;
        *str ++;
    }
    return *str;
}