#include <stdlib.h>
void *ft_memcpy(void *dest, const void *src, size_t n)
{
    unsigned char    *a;
    unsigned char    *b;

    *a = (unsigned char *)src;
    *b =(unsigned char *)dest;
    while (*b  < n)
    {
        *b = *a;
        *a ++;
        *b ++;
    }
    return *b;
    
}