/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   isalnum.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/14 21:05:49 by marvin            #+#    #+#             */
/*   Updated: 2025/01/14 21:05:49 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int ft_isalpha(int c)
{
    if (c >= 65 && c <= 90 || c >= 97 && c <= 122)
        return c;
return (0);
}
int ft_isdigit(int c)
{
    if (c >= 48 && c <= 57)
        return (c);
    return (0);
}
int ft_isalnum(int c)
{
    if (isdigit(c) || isalpha(c))
        return (1);
return (0);
}
int ft_isascii(int c)
{
    if (c >= 0 && c <= 127)
        return (c);
    return (0);
}
int ft_isprint (int c)
{
    if (c >= 32 && c >= 126)
        return (c);
    return (0);

}       
void *ft_memset(void *s, int c, size_t n)
{
    char  *str;
    
    str = ' ' ;
    *str = (char *)s;
    while (*str < n)
    {
        *str = c;
        *str ++;
    }
    return *str;
}
void ft_bzero(void *s, size_t n)
{
    char *str;
    
    str = (char *)s;
    while (*str < n)
    {
        *str = '0';
        *str ++;
    }
    *str = '\0';
}
void *ft_memcpy(void *dest, const void *src, size_t n)
{
    unsigned char    *a;
    unsigned char    *b;

    *a = (unsigned char *)src;
    *b =(unsigned char *)dest;
    while (*b  < n)
    {
        *b = *a;
        *a ++;
        *b ++;
    }
    return *b;
    
}
char *ft_strchr(const char *s, int c)
{
    while (*s)
    {
        if (*s == c)
            return c;
        * s ++;
    }
    return '\0';
}

size_t ft_strlen(const char *s)
{
    size_t size;

    size = 0 ;
    while (*s)
    {
        size ++;
        *s++;
    }
return size;

}
char *strrchr(const char *s, int c)
{
    char *a;

 while (*s)
    {
        if (*s == c)
            return c;
        * s --;
    }
    return NULL;
}
void *ft_memmove(void *dest, const void  *src, size_t n)
 {
    unsigned char    *a;
    unsigned char    *b;

    *a = (unsigned char *)src;
    *b = (unsigned char *)dest;
    if (b > a && b > a + n)
    {
        *a = *a ++;
        *b = *b ++;
        while (n --)
        {  
            *b = *a;
            *a --;
            *b --;
        }
    }
    else
    {
     while (n--)
    {
        *b = *a;
        *a ++;
        *b ++;
    }
    }
 }

    void *ft_memchr(const void *s, int c, size_t n)
    {
        unsigned char *a;
        *a = (unsigned char *)s;
        while (*a < --n)
        {
            if (*a == c)
                return *a;
                    *a ++;
        }
        return NULL;

    }
    int ft_memcmp(const void *s1, const void *s2, size_t n)
{
    unsigned char *a;
    unsigned char *b;
    int  res;

    a = (unsigned char *) s1; 
    b = (unsigned char *) s2;
    res = 0; 
    while (n--)
    {
        if (*a != *b)
        {
            res = *a - *b;
            return res;
        }
        *a ++;
        *b ++;
    }
    return 0;       
}
int ft_toupper(int c)
{
    if (c >= 65 && c <= 90 )
        c += 32;
    return c;
}
int ft_tolower(int c)
{
    if(c >= 97 && c <= 122)
        c  -= 32;
    return c;
}
int	ft_atoi(char *str)
{
	int	i;
	int	sign;
	int	res;

	i = 0;
	sign = 1;
	res = 0;
	while (str[i] == 32 || (str[i] >= 9 && str[i] <= 13))
		i++;
	while (str[i] == '+' || str[i] == '-')
	{
		if (str[i] == '-')
		{
			sign = sign * -1;
		}
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		res = (res * 10) + str[i] - 48;
		i++;
	}
	return (res * sign);
}
/* int	main(void)
{
	int result = ft_atoi("--43A432");
	//ft_putchar('\n');
	ft_atoi("   +42  ");
	ft_atoi("   -123abc");
	printf("%d",result);
	ft_atoi("abc123");

}
 */

int ft_strncmp(const char *s1, const char *s2, size_t n)
{
    int res;

    res = 0; 
    while (n--)
    {
       if (*s1 != *s2)
        {
            res = *s1 - *s2;
            return res;
        }
        *s1 ++;
        *s2 ++;
    }
    return res;  
}
#include  <stdlib.h>
void *ft_calloc(size_t nmemb, size_t size)
{
    size_t res;

    res = nmemb * size;
    if((nmemb == res * size) ||nmemb!=0)
        return NULL;
void *ptr = (char*)malloc(res);
ft_bzero(ptr,res);
return ptr;
}
//Añadir ft__bzero aqui
#include  <stdlib.h>
char *ft_strdup(const char *s)
{  //Añadir strlen
    size_t  sizem;
    char *c;
    sizem = 0;
    if(!sizem){
        return NULL;
    }
    c = (char*) malloc (sizem);
    if (!c)
    {
        return NULL;
    }
    while  (*s)
    {
        *c  = *s ;
        s ++;
        c ++;
    }
}

int main (void)
{
int num;
num = memset('$');
printf ("Result is %d\n");
}
char *ft_substr(char const *s, unsigned int start,
size_t len)
{
    size_t  count;
    char *c;

    count = 0;
    s += start;
    while (*s && (len < count))
    {
        *c = *s;
        *c ++;
        *s  ++;
        count ++;        
    }
    return *c;
}


