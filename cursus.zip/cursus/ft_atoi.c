/******************************************************************************/
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yael-you <yael-you@student.42madrid.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/14 16:07:56 by yael-you          #+#    #+#             */
/*   Updated: 2025/01/16 17:08:18 by yael-you         ###   ########.fr       */
/*                                                                            */
/******************************************************************************/

int	ft_atoi(char *str)
{
	int	i;
	int	sign;
	int	res;

	i = 0;
	sign = 1;
	res = 0;
	while (str[i] == 32 || (str[i] >= 9 && str[i] <= 13))
		i++;
	while (str[i] == '+' || str[i] == '-')
	{
		if (str[i] == '-')
		{
			sign = sign * -1;
		}
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		res = (res * 10) + str[i] - 48;
		i++;
	}
	return (res * sign);
}
/* int	main(void)
{
	int result = ft_atoi("--43A432");
	//ft_putchar('\n');
	ft_atoi("   +42  ");
	ft_atoi("   -123abc");
	printf("%d",result);
	ft_atoi("abc123");

}
 */