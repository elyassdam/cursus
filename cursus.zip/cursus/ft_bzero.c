
#include <stdlib.h>
void ft_bzero(void *s, size_t n)
{
    char *str;
    
    str = (char *)s;
    while (*str < n)
    {
        *str = '0';
        *str ++;
    }
    *str = '\0';
}