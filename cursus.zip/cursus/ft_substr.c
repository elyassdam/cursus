/******************************************************************************/
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yael-you <yael-you@student.42madrid.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/16 17:07:13 by yael-you          #+#    #+#             */
/*   Updated: 2025/01/16 17:07:29 by yael-you         ###   ########.fr       */
/*                                                                            */
/******************************************************************************/

#include <stdlib.h>
char *ft_substr(char const *s, unsigned int start,
size_t len)
{
    size_t  count;
    char *c;

    c = (char*) malloc (len + 1);

    count = 0;
    s += start;
    while (*s && (len < count))
    {
        *c = *s;
        *c ++;
        *s  ++;
        count ++;        
    }
    return *c;
}
