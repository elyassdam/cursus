#include <stdlib.h>
void *ft_memchr(const void *s, int c, size_t n)
{
unsigned char *a;
*a = (unsigned char *)s;
while (*a < --n)
{
    if (*a == c)
        return *a;
    *a ++;
        }
    return NULL;

    }