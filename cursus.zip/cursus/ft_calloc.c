#include  <stdlib.h>
void *ft_calloc(size_t nmemb, size_t size)
{
    size_t res;

    res = nmemb * size;
    if((nmemb == res * size) ||nmemb!=0)
        return NULL;
void *ptr = (char*)malloc(res);
ft_bzero(ptr,res);
return ptr;
}