#include  <stdlib.h>
char *ft_strdup(const char *s)
{  //Añadir strlen
    size_t  sizem;
    char *c;
    sizem = 0;
    if(!sizem){
        return NULL;
    }
    c = (char*) malloc (sizem + 1);
    if (!c)
    {
        return NULL;
    }
    while  (*s)
    {
        *c  = *s ;
        s ++;
        c ++;
    }
}