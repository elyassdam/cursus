#include <stdlib.h>
char *strrchr(const char *s, int c)
{
    char *a;

 while (*s)
    {
        if (*s == c)
            return c;
        * s --;
    }
    return NULL;
}